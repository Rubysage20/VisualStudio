﻿Imports System.Runtime.InteropServices

Public Class Form1


    Private Sub TransBtn_Click(sender As Object, e As EventArgs) Handles TransBtn.Click

        Dim englishWord As String = ""
        Dim targetLanguage As String = ComboBox1.SelectedItem.ToString()
        Dim translatedWord As String = ""

        ' Determine which radio button was selected'
        If MotherRadBtn.Checked Then
            englishWord = "Mother"
        ElseIf FatherRadBtn.Checked Then
            englishWord = "Father"
        ElseIf SisterRadBtn.Checked Then
            englishWord = "Sister"
        ElseIf BrotherRadBtn.Checked Then
            englishWord = "Brother"
        Else
            MessageBox.Show("Please select a English Word.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Get selected language from ComboBox'
        Select Case targetLanguage
            Case "French"
                translatedWord = TranslateToFrench(englishWord)
            Case "Italian"
                translatedWord = TranslateToItalian(englishWord)
            Case "Spanish"
                translatedWord = TranslateToSpanish(englishWord)
        End Select

        ' Display translated word in the label'
        lblTrans.Text = translatedWord

    End Sub

    Private Sub ExtBtn_Click(sender As Object, e As EventArgs) Handles ExtBtn.Click
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to exit the application ?", "Exit", MessageBoxButtons.YesNo)
        If result = DialogResult.Yes Then
            Me.Close()
        End If
    End Sub
    Function TranslateToFrench(englishWord) As String
        Select Case englishWord
            Case "Mother"
                Return "Mère"
            Case "Father"
                Return "Père"
            Case "Sister"
                Return "Soeur"
            Case "Brother"
                Return "Frère"
            Case Else
                Return "Translation not found"
        End Select
    End Function

    Function TranslateToItalian(englishWord) As String
        Select Case englishWord
            Case "Mother"
                Return "Madre"
            Case "Father"
                Return "Padre"
            Case "Sister"
                Return "Sorella"
            Case "Brother"
                Return "Fratello"
            Case Else
                Return "Translation not found"
        End Select
    End Function

    Function TranslateToSpanish(englishWord) As String
        Select Case englishWord
            Case "Mother"
                Return "Madre"
            Case "Father"
                Return "Padre"
            Case "Sister"
                Return "Hermana"
            Case "Brother"
                Return "Hermano"
            Case Else
                Return "Translation not found"
        End Select
    End Function


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load, ComboBox1.SelectedIndexChanged
        ' Populate the Combobox1 wuth target languages'
        If ComboBox1.Items.Count = 0 Then
            ComboBox1.Items.Add("French")
            ComboBox1.Items.Add("Italian")
            ComboBox1.Items.Add("Spanish")
            ComboBox1.SelectedIndex = 0 ' Set the default selected language'
        End If
    End Sub

    Private Sub lblTrans_Click(sender As Object, e As EventArgs) Handles lblTrans.Click
        lblTrans.Text = String.Empty ' Clear label contents'
    End Sub


End Class
