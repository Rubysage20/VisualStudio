﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.MotherRadBtn = New System.Windows.Forms.RadioButton()
        Me.FatherRadBtn = New System.Windows.Forms.RadioButton()
        Me.SisterRadBtn = New System.Windows.Forms.RadioButton()
        Me.BrotherRadBtn = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblTrans = New System.Windows.Forms.Label()
        Me.TransBtn = New System.Windows.Forms.Button()
        Me.ExtBtn = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(627, 139)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(368, 45)
        Me.ComboBox1.TabIndex = 1
        '
        'MotherRadBtn
        '
        Me.MotherRadBtn.AutoSize = True
        Me.MotherRadBtn.Location = New System.Drawing.Point(45, 84)
        Me.MotherRadBtn.Name = "MotherRadBtn"
        Me.MotherRadBtn.Size = New System.Drawing.Size(160, 41)
        Me.MotherRadBtn.TabIndex = 1
        Me.MotherRadBtn.TabStop = True
        Me.MotherRadBtn.Text = "Mother"
        Me.MotherRadBtn.UseVisualStyleBackColor = True
        '
        'FatherRadBtn
        '
        Me.FatherRadBtn.AutoSize = True
        Me.FatherRadBtn.Location = New System.Drawing.Point(43, 163)
        Me.FatherRadBtn.Name = "FatherRadBtn"
        Me.FatherRadBtn.Size = New System.Drawing.Size(154, 41)
        Me.FatherRadBtn.TabIndex = 2
        Me.FatherRadBtn.TabStop = True
        Me.FatherRadBtn.Text = "Father"
        Me.FatherRadBtn.UseVisualStyleBackColor = True
        '
        'SisterRadBtn
        '
        Me.SisterRadBtn.AutoSize = True
        Me.SisterRadBtn.Location = New System.Drawing.Point(43, 240)
        Me.SisterRadBtn.Name = "SisterRadBtn"
        Me.SisterRadBtn.Size = New System.Drawing.Size(142, 41)
        Me.SisterRadBtn.TabIndex = 3
        Me.SisterRadBtn.TabStop = True
        Me.SisterRadBtn.Text = "Sister"
        Me.SisterRadBtn.UseVisualStyleBackColor = True
        '
        'BrotherRadBtn
        '
        Me.BrotherRadBtn.AutoSize = True
        Me.BrotherRadBtn.Location = New System.Drawing.Point(41, 319)
        Me.BrotherRadBtn.Name = "BrotherRadBtn"
        Me.BrotherRadBtn.Size = New System.Drawing.Size(166, 41)
        Me.BrotherRadBtn.TabIndex = 4
        Me.BrotherRadBtn.TabStop = True
        Me.BrotherRadBtn.Text = "Brother"
        Me.BrotherRadBtn.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(627, 96)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(196, 37)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Translate to:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.BrotherRadBtn)
        Me.GroupBox1.Controls.Add(Me.MotherRadBtn)
        Me.GroupBox1.Controls.Add(Me.FatherRadBtn)
        Me.GroupBox1.Controls.Add(Me.SisterRadBtn)
        Me.GroupBox1.Location = New System.Drawing.Point(61, 36)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(389, 403)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "English"
        '
        'lblTrans
        '
        Me.lblTrans.AutoSize = True
        Me.lblTrans.BackColor = System.Drawing.SystemColors.Control
        Me.lblTrans.Location = New System.Drawing.Point(898, 201)
        Me.lblTrans.Name = "lblTrans"
        Me.lblTrans.Size = New System.Drawing.Size(0, 37)
        Me.lblTrans.TabIndex = 7
        '
        'TransBtn
        '
        Me.TransBtn.AutoSize = True
        Me.TransBtn.Location = New System.Drawing.Point(1158, 120)
        Me.TransBtn.Name = "TransBtn"
        Me.TransBtn.Size = New System.Drawing.Size(189, 53)
        Me.TransBtn.TabIndex = 8
        Me.TransBtn.Text = "Translate"
        Me.TransBtn.UseVisualStyleBackColor = True
        '
        'ExtBtn
        '
        Me.ExtBtn.AutoSize = True
        Me.ExtBtn.Location = New System.Drawing.Point(1158, 212)
        Me.ExtBtn.Name = "ExtBtn"
        Me.ExtBtn.Size = New System.Drawing.Size(189, 49)
        Me.ExtBtn.TabIndex = 9
        Me.ExtBtn.Text = "Exit"
        Me.ExtBtn.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Location = New System.Drawing.Point(627, 199)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(265, 37)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Translated Word:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(19.0!, 37.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1696, 570)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ExtBtn)
        Me.Controls.Add(Me.TransBtn)
        Me.Controls.Add(Me.lblTrans)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Translator"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MotherRadBtn As RadioButton
    Friend WithEvents FatherRadBtn As RadioButton
    Friend WithEvents SisterRadBtn As RadioButton
    Friend WithEvents BrotherRadBtn As RadioButton
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lblTrans As Label
    Friend WithEvents TransBtn As Button
    Friend WithEvents ExtBtn As Button
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Label2 As Label
End Class
