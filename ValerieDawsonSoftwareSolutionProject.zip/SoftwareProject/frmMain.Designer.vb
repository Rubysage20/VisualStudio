﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.NoDiscBtn = New System.Windows.Forms.RadioButton()
        Me.ediGrpBox = New System.Windows.Forms.GroupBox()
        Me.StuRadBtn = New System.Windows.Forms.RadioButton()
        Me.ProfRadBtn = New System.Windows.Forms.RadioButton()
        Me.ultRadBtn = New System.Windows.Forms.RadioButton()
        Me.GetPriceBtn = New System.Windows.Forms.Button()
        Me.ExitBtn = New System.Windows.Forms.Button()
        Me.UltEdiDisc = New System.Windows.Forms.RadioButton()
        Me.StuDisBtn = New System.Windows.Forms.RadioButton()
        Me.priceLabel = New System.Windows.Forms.Label()
        Me.priceOutLabl = New System.Windows.Forms.Label()
        Me.ediGrpBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'NoDiscBtn
        '
        Me.NoDiscBtn.AutoSize = True
        Me.NoDiscBtn.Location = New System.Drawing.Point(548, 60)
        Me.NoDiscBtn.Name = "NoDiscBtn"
        Me.NoDiscBtn.Size = New System.Drawing.Size(237, 41)
        Me.NoDiscBtn.TabIndex = 3
        Me.NoDiscBtn.TabStop = True
        Me.NoDiscBtn.Text = "No Discount"
        Me.NoDiscBtn.UseVisualStyleBackColor = True
        '
        'ediGrpBox
        '
        Me.ediGrpBox.Controls.Add(Me.StuRadBtn)
        Me.ediGrpBox.Controls.Add(Me.ProfRadBtn)
        Me.ediGrpBox.Controls.Add(Me.ultRadBtn)
        Me.ediGrpBox.Location = New System.Drawing.Point(89, 36)
        Me.ediGrpBox.Name = "ediGrpBox"
        Me.ediGrpBox.Size = New System.Drawing.Size(431, 258)
        Me.ediGrpBox.TabIndex = 0
        Me.ediGrpBox.TabStop = False
        Me.ediGrpBox.Text = "Edition"
        '
        'StuRadBtn
        '
        Me.StuRadBtn.AutoSize = True
        Me.StuRadBtn.Location = New System.Drawing.Point(54, 191)
        Me.StuRadBtn.Name = "StuRadBtn"
        Me.StuRadBtn.Size = New System.Drawing.Size(171, 41)
        Me.StuRadBtn.TabIndex = 2
        Me.StuRadBtn.TabStop = True
        Me.StuRadBtn.Text = "Student"
        Me.StuRadBtn.UseVisualStyleBackColor = True
        '
        'ProfRadBtn
        '
        Me.ProfRadBtn.AutoSize = True
        Me.ProfRadBtn.Location = New System.Drawing.Point(54, 124)
        Me.ProfRadBtn.Name = "ProfRadBtn"
        Me.ProfRadBtn.Size = New System.Drawing.Size(237, 41)
        Me.ProfRadBtn.TabIndex = 1
        Me.ProfRadBtn.TabStop = True
        Me.ProfRadBtn.Text = "Professional"
        Me.ProfRadBtn.UseVisualStyleBackColor = True
        '
        'ultRadBtn
        '
        Me.ultRadBtn.AutoSize = True
        Me.ultRadBtn.Location = New System.Drawing.Point(54, 59)
        Me.ultRadBtn.Name = "ultRadBtn"
        Me.ultRadBtn.Size = New System.Drawing.Size(187, 41)
        Me.ultRadBtn.TabIndex = 0
        Me.ultRadBtn.TabStop = True
        Me.ultRadBtn.Text = "Ultimate "
        Me.ultRadBtn.UseVisualStyleBackColor = True
        '
        'GetPriceBtn
        '
        Me.GetPriceBtn.Location = New System.Drawing.Point(1064, 60)
        Me.GetPriceBtn.Name = "GetPriceBtn"
        Me.GetPriceBtn.Size = New System.Drawing.Size(222, 76)
        Me.GetPriceBtn.TabIndex = 1
        Me.GetPriceBtn.Text = "Get price"
        Me.GetPriceBtn.UseVisualStyleBackColor = True
        '
        'ExitBtn
        '
        Me.ExitBtn.Location = New System.Drawing.Point(1064, 160)
        Me.ExitBtn.Name = "ExitBtn"
        Me.ExitBtn.Size = New System.Drawing.Size(222, 62)
        Me.ExitBtn.TabIndex = 2
        Me.ExitBtn.Text = "Exit"
        Me.ExitBtn.UseVisualStyleBackColor = True
        '
        'UltEdiDisc
        '
        Me.UltEdiDisc.AutoSize = True
        Me.UltEdiDisc.Location = New System.Drawing.Point(548, 139)
        Me.UltEdiDisc.Name = "UltEdiDisc"
        Me.UltEdiDisc.Size = New System.Drawing.Size(414, 41)
        Me.UltEdiDisc.TabIndex = 4
        Me.UltEdiDisc.TabStop = True
        Me.UltEdiDisc.Text = "Ultimate Edition discount"
        Me.UltEdiDisc.UseVisualStyleBackColor = True
        '
        'StuDisBtn
        '
        Me.StuDisBtn.AutoSize = True
        Me.StuDisBtn.Location = New System.Drawing.Point(548, 210)
        Me.StuDisBtn.Name = "StuDisBtn"
        Me.StuDisBtn.Size = New System.Drawing.Size(407, 41)
        Me.StuDisBtn.TabIndex = 5
        Me.StuDisBtn.TabStop = True
        Me.StuDisBtn.Text = "Student Edition discount"
        Me.StuDisBtn.UseVisualStyleBackColor = True
        '
        'priceLabel
        '
        Me.priceLabel.AutoSize = True
        Me.priceLabel.Location = New System.Drawing.Point(548, 292)
        Me.priceLabel.Name = "priceLabel"
        Me.priceLabel.Size = New System.Drawing.Size(98, 37)
        Me.priceLabel.TabIndex = 6
        Me.priceLabel.Text = "Price:"
        '
        'priceOutLabl
        '
        Me.priceOutLabl.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.priceOutLabl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.priceOutLabl.Location = New System.Drawing.Point(555, 360)
        Me.priceOutLabl.Name = "priceOutLabl"
        Me.priceOutLabl.Size = New System.Drawing.Size(153, 46)
        Me.priceOutLabl.TabIndex = 7
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(19.0!, 37.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(1458, 561)
        Me.Controls.Add(Me.priceOutLabl)
        Me.Controls.Add(Me.priceLabel)
        Me.Controls.Add(Me.StuDisBtn)
        Me.Controls.Add(Me.UltEdiDisc)
        Me.Controls.Add(Me.NoDiscBtn)
        Me.Controls.Add(Me.ExitBtn)
        Me.Controls.Add(Me.GetPriceBtn)
        Me.Controls.Add(Me.ediGrpBox)
        Me.Name = "Form1"
        Me.Text = "Software Haven"
        Me.ediGrpBox.ResumeLayout(False)
        Me.ediGrpBox.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ediGrpBox As GroupBox
    Friend WithEvents ultRadBtn As RadioButton
    Friend WithEvents ProfRadBtn As RadioButton
    Friend WithEvents StuRadBtn As RadioButton
    Friend WithEvents GetPriceBtn As Button
    Friend WithEvents ExitBtn As Button
    Friend WithEvents UltEdiDisc As RadioButton
    Friend WithEvents StuDisBtn As RadioButton
    Friend WithEvents priceLabel As Label
    Friend WithEvents priceOutLabl As Label
    Friend WithEvents NoDiscBtn As RadioButton
End Class
