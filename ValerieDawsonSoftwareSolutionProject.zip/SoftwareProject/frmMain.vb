﻿Public Class Form1
    'Constants for edition prices 
    Const UltimatePrice As Double = 899.99
    Const ProfessionalPrice As Double = 599.99
    Const StudentPrice As Double = 99.99


    Private Sub GetPriceBtn_Click(sender As Object, e As EventArgs) Handles GetPriceBtn.Click
        Dim price As Double = 0

        If ultRadBtn.Checked Then
            price = UltimatePrice
            UltEdiDisc.Enabled = True
            StuDisBtn.Enabled = False
            NoDiscBtn.Enabled = True
        End If

        If ProfRadBtn.Checked Then
            price = ProfessionalPrice
            StuDisBtn.Enabled = False
            NoDiscBtn.Enabled = True
            UltEdiDisc.Enabled = False

        End If

        If StuRadBtn.Checked Then
            price = StudentPrice
            StuDisBtn.Enabled = True
            UltEdiDisc.Enabled = False
            NoDiscBtn.Enabled = True

        End If

        If UltEdiDisc.Checked Then
            price = UltimatePrice * 0.9 '10% discount
        End If

        If StuDisBtn.Checked Then
                price = StudentPrice * 0.8 '20% discount 
            End If

        priceOutLabl.Text = "$" & price.ToString("F2")

    End Sub

    Private Sub ExitBtn_Click(sender As Object, e As EventArgs) Handles ExitBtn.Click
        Me.Close()
    End Sub

    Private Sub NoDiscBtn_CheckedChanged(sender As Object, e As EventArgs) Handles NoDiscBtn.CheckedChanged

    End Sub

    Private Sub ultRadBtn_CheckedChanged(sender As Object, e As EventArgs) Handles ultRadBtn.CheckedChanged
        If ultRadBtn.Checked Then
            StuDisBtn.Enabled = False
            NoDiscBtn.Enabled = True
            UltEdiDisc.Enabled = True
        End If
    End Sub

    Private Sub ProfRadBtn_CheckedChanged(sender As Object, e As EventArgs) Handles ProfRadBtn.CheckedChanged
        If ProfRadBtn.Checked Then
            UltEdiDisc.Enabled = False
            NoDiscBtn.Enabled = True
            StuDisBtn.Enabled = False
        End If
    End Sub

    Private Sub StuRadBtn_CheckedChanged(sender As Object, e As EventArgs) Handles StuRadBtn.CheckedChanged
        If StuRadBtn.Checked Then
            StuDisBtn.Enabled = True
            UltEdiDisc.Enabled = False
            NoDiscBtn.Enabled = True
        End If
    End Sub
End Class
