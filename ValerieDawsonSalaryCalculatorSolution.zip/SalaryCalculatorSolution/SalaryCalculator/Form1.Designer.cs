﻿namespace SalaryCalculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.currentSalaryTextBox = new System.Windows.Forms.TextBox();
            this.newSalary5PercentLabel = new System.Windows.Forms.Label();
            this.newSalary8PercentLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.currentSalaryLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // currentSalaryTextBox
            // 
            this.currentSalaryTextBox.Location = new System.Drawing.Point(1031, 58);
            this.currentSalaryTextBox.Name = "currentSalaryTextBox";
            this.currentSalaryTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.currentSalaryTextBox.Size = new System.Drawing.Size(310, 44);
            this.currentSalaryTextBox.TabIndex = 0;
            // 
            // newSalary5PercentLabel
            // 
            this.newSalary5PercentLabel.AutoSize = true;
            this.newSalary5PercentLabel.Location = new System.Drawing.Point(67, 155);
            this.newSalary5PercentLabel.Name = "newSalary5PercentLabel";
            this.newSalary5PercentLabel.Size = new System.Drawing.Size(293, 37);
            this.newSalary5PercentLabel.TabIndex = 3;
            this.newSalary5PercentLabel.Text = "Salary Raise by 5%";
            // 
            // newSalary8PercentLabel
            // 
            this.newSalary8PercentLabel.AutoSize = true;
            this.newSalary8PercentLabel.Location = new System.Drawing.Point(67, 226);
            this.newSalary8PercentLabel.Name = "newSalary8PercentLabel";
            this.newSalary8PercentLabel.Size = new System.Drawing.Size(293, 37);
            this.newSalary8PercentLabel.TabIndex = 4;
            this.newSalary8PercentLabel.Text = "Salary Raise by 8%";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(201, 546);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(217, 53);
            this.calculateButton.TabIndex = 5;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(1136, 546);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(184, 53);
            this.clearButton.TabIndex = 6;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // currentSalaryLabel
            // 
            this.currentSalaryLabel.AutoSize = true;
            this.currentSalaryLabel.Location = new System.Drawing.Point(52, 58);
            this.currentSalaryLabel.Name = "currentSalaryLabel";
            this.currentSalaryLabel.Size = new System.Drawing.Size(381, 37);
            this.currentSalaryLabel.TabIndex = 7;
            this.currentSalaryLabel.Text = "Enter your current Salary:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1428, 656);
            this.Controls.Add(this.currentSalaryLabel);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.newSalary8PercentLabel);
            this.Controls.Add(this.newSalary5PercentLabel);
            this.Controls.Add(this.currentSalaryTextBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox currentSalaryTextBox;
        private System.Windows.Forms.Label newSalary5PercentLabel;
        private System.Windows.Forms.Label newSalary8PercentLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Label currentSalaryLabel;
    }
}

