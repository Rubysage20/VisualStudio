﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalaryCalculator {

public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
    }

    private void calculateButton_Click(object sender, EventArgs e)
    {
        if (double.TryParse(currentSalaryTextBox.Text, out double currentSalary))
        {   // Calculate the raise amounts 
            double raise5Percent = currentSalary * 0.5;
            double raise8Percent = currentSalary * 0.8;
                // Calculate the new salaries
            double newSalary5Percent = currentSalary + raise5Percent;
            double newSalary8Percent = currentSalary + raise8Percent;

            // Display the raise amounts and new salaries in the corresponding labels
                newSalary5PercentLabel.Text = $" New Salary with 5% Raise: {newSalary5Percent:C}";
                newSalary8PercentLabel.Text = $" New Salary with 8% Raise: {newSalary8Percent:C}";
        }
        else
        { // Display an error message if the input is not a valid number
            MessageBox.Show("Please enter a valid number for the current salary.");
        }
        }
        // Event handler for the Clear button
        private void clearButton_Click(object sender, EventArgs e)
        { // Clear the input and calculated results from the screen
            currentSalaryTextBox.Text = "";
            newSalary5PercentLabel.Text = "";
            newSalary8PercentLabel.Text = "";
        }
        }
    }


