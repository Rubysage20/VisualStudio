﻿Imports System.IO

Public Class FrmMain
    'List to store items in Need to Visit.txt and Visited.txt 
    Private NeedToVisitList As New List(Of String)
    Private VisitedList As New List(Of String)

    ' Filepaths 
    Private NeedToVisitFilePath As String = "NeedToVisit.txt"
    Private VisitedFilePath As String = "Visited.txt"

    'Flag to track if changes were made
    Private ChangesMade As Boolean = False
    Private Sub FrmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Load items from txt files into list boxes when form loads
        LoadItemsFromFiles()
    End Sub

    Private Sub LoadItemsFromFiles()

        'Load items from txt files into list boxes 
        If File.Exists(NeedToVisitFilePath) Then
            Dim lines As String() = File.ReadAllLines(NeedToVisitFilePath)
            NeedToVisitList.AddRange(lines)
            lstNeed.Items.AddRange(lines)
        End If

        If File.Exists(VisitedFilePath) Then
            Dim lines As String() = File.ReadAllLines(VisitedFilePath)
            VisitedList.AddRange(lines)
            lstVisited.Items.AddRange(lines)
        End If

        If lstNeed.Items.Count > 0 Then
            lstNeed.SelectedIndex = 0
        End If
    End Sub

    Private Sub lstNeed_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstNeed.SelectedIndexChanged

    End Sub

    Private Sub lstVisited_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstVisited.SelectedIndexChanged

    End Sub

    Private Sub btnMoveToVisited_Click(sender As Object, e As EventArgs) Handles btnMoveToVisited.Click
        ' Move selected items from lstNeed to lstVisited and update lists
        If lstNeed.SelectedIndex <> -1 Then
            Dim selectedItem As String = lstNeed.SelectedItem.ToString()
            lstVisited.Items.Add(selectedItem)
            VisitedList.Add(selectedItem)
            NeedToVisitList.RemoveAt(lstNeed.SelectedIndex)
            lstNeed.Items.RemoveAt(lstNeed.SelectedIndex)
            ChangesMade = True
        End If
    End Sub
    Private Sub FrmMain_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        If ChangesMade Then
            Dim result As DialogResult = MessageBox.Show("Do you want to save the changes?", "Save Changes",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If result = DialogResult.Yes Then
                SaveItemsToFile(NeedToVisitList, NeedToVisitFilePath)
                SaveItemsToFile(VisitedList, VisitedFilePath)
            ElseIf result = DialogResult.Cancel Then
                'If user chooses Cancel , do nothing and return
                Return
            End If
        End If

    End Sub

    Private Sub SaveItemsToFile(items As List(Of String), filePath As String)

        ' Save data from NeedToVisitList and VisitedList to NeedToVisit.txt and Visited.txt files
        File.WriteAllLines(filePath, items.ToArray())
    End Sub

    Private Sub extBtn_Click(sender As Object, e As EventArgs) Handles extBtn.Click
        'Close the form when the exit button is clicked 
        Me.Close()
    End Sub


End Class
